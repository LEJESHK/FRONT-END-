import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import java.io.File;

public class lab {
    public static void main(String[] args) {
        try {
            // Load and parse the XML file
            File xmlFile = new File("students.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            
            // Normalize the XML structure
           Element root= doc.getDocumentElement();
            
            System.out.println("Root element: " + root.getNodeName());
            
            // Get all <student> elements
            NodeList nodeList = root.getChildNodes();
            
            // Iterate through each <student> node
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                    
                    // Retrieve and print the data
                    String firstName = element.getElementsByTagName("firstname").item(0).getTextContent();
                    String lastName = element.getElementsByTagName("lastname").item(0).getTextContent();
                    String age = element.getElementsByTagName("age").item(0).getTextContent();
                    
                    System.out.println("Student:");
                    System.out.println("First Name: " + firstName);
                    System.out.println("Last Name: " + lastName);
                    System.out.println("Age: " + age);
                    System.out.println();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
