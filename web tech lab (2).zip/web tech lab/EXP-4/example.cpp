<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation with Regex and Food Preferences</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Login here!</h2>
<form id="myForm">
    <!-- Text field validation -->
    Name: <input type="text" id="name" /><br><br>
    Email: <input type="email" id="email" /><br><br>

    <!-- Radio button validation -->
    Gender:
    <input type="radio" name="gender" value="male" /> Male
    <input type="radio" name="gender" value="female" /> Female
<br><br>

    <!-- Checkbox validation -->
    Food Preferences:
    <input type="checkbox" name="food" value="vegetarian" /> Vegetarian
  
    <input type="checkbox" name="food" value="non-vegetarian" /> Non-Vegetarian<br><br>

    <!-- Listbox validation -->
    Country:
    <select id="country">
        <option value="">--Select a Country--</option>
        <option value="USA">USA</option>
        <option value="Canada">Canada</option>
        <option value="India">India</option>
    </select><br><br>

    <input type="submit" value="Submit" />
</form>

<script>
  document.getElementById('myForm').onsubmit = function(event) {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var genders = document.getElementsByName('gender');
    var foodPreferences = document.getElementsByName('food');
    var country = document.getElementById('country').value;

    // Regular Expressions for validation
    var nameRegex = /^[a-zA-Z\s]+$/;  // Allows only alphabets and spaces
    var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;  // Standard email pattern

    // Name validation with regex
    if (!nameRegex.test(name)) {
      alert('Name can only contain letters and spaces');
      event.preventDefault();
    }

    // Email validation with regex
    if (!emailRegex.test(email)) {
      alert('Please enter a valid email address');
      event.preventDefault();
    }

    // Radio button validation
    var isGenderSelected = false;
    for (var i = 0; i < genders.length; i++) {
      if (genders[i].checked) {
        isGenderSelected = true;
        break;
      }
    }
    if (!isGenderSelected) {
      alert('Please select your gender');
      event.preventDefault();
    }

    // Checkbox validation for food preferences
    var isFoodChecked = false;
    for (var i = 0; i < foodPreferences.length; i++) {
      if (foodPreferences[i].checked) {
        isFoodChecked = true;
        break;
      }
    }
    if (!isFoodChecked) {
      alert('Please select at least one food preference');
      event.preventDefault();
    }

    // Listbox validation
    if (country === '') {
      alert('Please select a country');
      event.preventDefault();
    }
  };
</script>

</body>
</html>
